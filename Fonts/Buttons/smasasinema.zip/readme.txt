Creative Commons Attribution Non-commercial No Derivatives
http://creativecommons.org/licenses/by-nc-nd/3.0/
